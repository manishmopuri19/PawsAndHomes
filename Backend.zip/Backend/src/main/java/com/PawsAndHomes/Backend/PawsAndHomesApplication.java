package com.PawsAndHomes.Backend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PawsAndHomesApplication {

	public static void main(String[] args) {
		SpringApplication.run(PawsAndHomesApplication.class, args);
	}

}
